$(document).ready(function () {
  $("#login-form").on("submit", function (e) {
    e.preventDefault();

    const email = $("#emailEmpresa").val().trim();
    const senha = $("#senhaEmpresa").val().trim();

    // Validação simples
    if (!email || !senha) {
      $("#mensagem").text("Preencha todos os campos.").css("color", "red");
      return;
    }

    // Regex para email válido
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      $("#mensagem").text("Digite um email válido.").css("color", "red");
      return;
    }

    if (senha.length < 6) {
      $("#mensagem").text("A senha deve ter pelo menos 6 caracteres.").css("color", "red");
      return;
    }

    // Se passou, manda pro backend
    $.ajax({
      url: "http://localhost:3000/api/login",
      type: "POST",
      contentType: "application/json",
      data: JSON.stringify({ emailEmpresa: email, senhaEmpresa: senha }),
      success: function (res) {
        $("#mensagem").text(res.message).css("color", "green");
        if (res.token) {
          localStorage.setItem("token", res.token);
          localStorage.setItem("empresa", JSON.stringify(res.empresa));
        }
        setTimeout(() => {
          window.location.href = "../tela final/tela final.html";
        }, 1000);
      },
      error: function (xhr) {
        $("#mensagem").text(xhr.responseJSON?.message || "Erro no login").css("color", "red");
      }
    });
  });
});
