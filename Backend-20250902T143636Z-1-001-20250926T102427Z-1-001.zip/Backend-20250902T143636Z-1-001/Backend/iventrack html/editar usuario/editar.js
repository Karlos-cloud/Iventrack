$(document).ready(function () {
  const empresa = JSON.parse(localStorage.getItem("empresa")); // 👈 recupera dados salvos no login
  if (!empresa) {
    alert("Você precisa estar logado para editar o perfil!");
    window.location.href = "../tela de login/tela login.html";
    return;
  }

  // Preenche os campos com os dados atuais
  $("#nome").val(empresa.nome);
  $("#email").val(empresa.email);

  // Preview da foto (apenas visual, sem backend ainda)
  $("#foto").on("change", function (e) {
    const file = e.target.files[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = function (ev) {
        $("#foto-preview").attr("src", ev.target.result);
      };
      reader.readAsDataURL(file);
    }
  });

  // Envia atualização
  $("#form-editar").on("submit", function (e) {
    e.preventDefault();

    const nome = $("#nome").val().trim();
    const email = $("#email").val().trim();
    const senha = $("#senha").val().trim();

    if (!nome || !email) {
      $("#mensagem").text("Nome e Email são obrigatórios").css("color", "red");
      return;
    }

    $.ajax({
      url: `http://localhost:3000/api/empresa/${empresa.id}`, // PUT com id
      type: "PUT",
      contentType: "application/json",
      data: JSON.stringify({
        nomeEmpresa: nome,
        emailEmpresa: email,
        senhaEmpresa: senha || undefined // só manda se usuário preencher
      }),
      success: function (res) {
        $("#mensagem").text(res.message).css("color", "green");

        // Atualiza no localStorage também
        localStorage.setItem("empresa", JSON.stringify(res.empresa));

        setTimeout(() => {
          window.location.href = "../tela final/tela final.html";
        }, 1500);
      },
      error: function (xhr) {
        $("#mensagem").text(xhr.responseJSON?.message || "Erro ao atualizar").css("color", "red");
      }
    });
  });
});
