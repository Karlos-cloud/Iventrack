import express from 'express';
import { sequelize } from './database/connection.js';
import cors from 'cors';
import authRoutes from './routes/authRoutes.js';
import empresaRoutes from './routes/empresaRoutes.js';

const app = express();

app.use(cors());
app.use(express.json());

// Rotas
app.use('/api', authRoutes);
app.use('/api', empresaRoutes);

const PORT = 3000;

(async () => {
  try {
    await sequelize.sync(); // Garante que modelo e tabela estejam alinhados
    app.listen(PORT, () => {
      console.log(`Servidor rodando em http://localhost:${PORT}`);
    });
  } catch (err) {
    console.error('Erro ao sincronizar banco:', err);
  }
})();