// src/controllers/empresa.js
import { Empresa } from '../database/models/Empresa.js';

// Auxiliar
const buscarEmpresaPorId = async (id) => {
  const empresa = await Empresa.findByPk(id);
  if (!empresa) throw new Error('Empresa não encontrada');
  return empresa;
};

// Cadastro
export const cadastrarEmpresa = async (req, res) => {
  try {
    const { nomeEmpresa, emailEmpresa, senhaEmpresa } = req.body;

    if (!nomeEmpresa || !emailEmpresa || !senhaEmpresa) {
      return res.status(400).json({ message: 'Preencha todos os campos' });
    }
    if (nomeEmpresa.length < 3) {
      return res.status(400).json({ message: 'O nome deve ter pelo menos 3 caracteres' });
    }
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(emailEmpresa)) {
      return res.status(400).json({ message: 'Digite um email válido' });
    }
    if (senhaEmpresa.length < 6) {
      return res.status(400).json({ message: 'A senha deve ter no mínimo 6 caracteres' });
    }

    const existente = await Empresa.findOne({ where: { emailEmpresa } });
    if (existente) {
      return res.status(400).json({ message: 'Este email já está cadastrado' });
    }

    const nova = await Empresa.create({ nomeEmpresa, emailEmpresa, senhaEmpresa });

    return res.status(201).json({
      message: 'Empresa cadastrada com sucesso!',
      empresa: {
        id: nova.IDEmpresa,
        nome: nova.nomeEmpresa,
        email: nova.emailEmpresa
      }
    });
  } catch (err) {
    console.error('Erro cadastrarEmpresa:', err);
    return res.status(500).json({ message: 'Erro ao cadastrar empresa' });
  }
};

// Listar todas
export const listarEmpresas = async (req, res) => {
  try {
    const empresas = await Empresa.findAll();
    return res.status(200).json(empresas);
  } catch (err) {
    console.error('Erro listarEmpresas:', err);
    return res.status(500).json({ message: 'Erro ao listar empresas' });
  }
};

// Buscar por id
export const buscarEmpresa = async (req, res) => {
  try {
    const empresa = await buscarEmpresaPorId(req.params.id);
    return res.status(200).json(empresa);
  } catch (err) {
    console.error('Erro buscarEmpresa:', err);
    return res.status(404).json({ message: err.message || 'Erro ao buscar empresa' });
  }
};

// Atualizar empresa (editar perfil)
export const atualizarEmpresa = async (req, res) => {
  try {
    const { id } = req.params;
    const { nomeEmpresa, emailEmpresa, senhaEmpresa } = req.body;

    // 🔹 Verifica se a empresa existe
    const empresa = await Empresa.findByPk(id);
    if (!empresa) {
      return res.status(404).json({ message: "Empresa não encontrada" });
    }

    // 🔹 Validações opcionais
    if (nomeEmpresa && nomeEmpresa.length < 3) {
      return res.status(400).json({ message: "O nome deve ter pelo menos 3 caracteres" });
    }
    if (emailEmpresa) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(emailEmpresa)) {
        return res.status(400).json({ message: "Digite um email válido" });
      }
      // Verifica se o email já está em uso
      const existente = await Empresa.findOne({ where: { emailEmpresa } });
      if (existente && existente.IDEmpresa !== empresa.IDEmpresa) {
        return res.status(400).json({ message: "Este email já está em uso" });
      }
    }
    if (senhaEmpresa && senhaEmpresa.length < 6) {
      return res.status(400).json({ message: "A senha deve ter no mínimo 6 caracteres" });
    }

    // 🔹 Atualiza apenas os campos enviados
    empresa.nomeEmpresa = nomeEmpresa || empresa.nomeEmpresa;
    empresa.emailEmpresa = emailEmpresa || empresa.emailEmpresa;
    empresa.senhaEmpresa = senhaEmpresa || empresa.senhaEmpresa;

    await empresa.save();

    return res.status(200).json({
      message: "Perfil atualizado com sucesso!",
      empresa: {
        id: empresa.IDEmpresa,
        nome: empresa.nomeEmpresa,
        email: empresa.emailEmpresa
      }
    });
  } catch (err) {
    console.error("Erro editarEmpresa:", err);
    return res.status(500).json({ message: "Erro ao editar empresa" });
  }
};