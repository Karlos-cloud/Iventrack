const express = require("express");
const router = express.Router();
const db = require("../db");

// CREATE
router.post("/", (req, res) => {
  const { quantidade, IDProduto, IDEmpresa } = req.body;
  db.query(
    "INSERT INTO tbEstoque (quantidade, IDProduto, IDEmpresa) VALUES (?, ?, ?)",
    [quantidade, IDProduto, IDEmpresa],
    (err, result) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ message: "Estoque registrado!", id: result.insertId });
    }
  );
});

// READ ALL
router.get("/", (req, res) => {
  db.query("SELECT * FROM tbEstoque", (err, results) => {
    if (err) return res.status(500).json({ error: err });
    res.json(results);
  });
});

// READ ONE
router.get("/:id", (req, res) => {
  const { id } = req.params;
  db.query("SELECT * FROM tbEstoque WHERE IDEstoque=?", [id], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json(result[0]);
  });
});

// UPDATE
router.put("/:id", (req, res) => {
  const { id } = req.params;
  const { quantidade, IDProduto, IDEmpresa } = req.body;
  db.query(
    "UPDATE tbEstoque SET quantidade=?, IDProduto=?, IDEmpresa=? WHERE IDEstoque=?",
    [quantidade, IDProduto, IDEmpresa, id],
    (err) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ message: "Estoque atualizado!" });
    }
  );
});

// DELETE
router.delete("/:id", (req, res) => {
  const { id } = req.params;
  db.query("DELETE FROM tbEstoque WHERE IDEstoque=?", [id], (err) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: "Estoque deletado!" });
  });
});

module.exports = router;
