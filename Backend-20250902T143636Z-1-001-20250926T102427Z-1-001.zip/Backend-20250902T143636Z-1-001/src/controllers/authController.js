import { sequelize } from '../database/connection.js';
import { QueryTypes } from 'sequelize';

export const login = async (req, res) => {
  const { emailEmpresa, senhaEmpresa } = req.body;

  // 1) Verificação de campos obrigatórios
  if (!emailEmpresa || !senhaEmpresa) {
    return res.status(400).json({ message: "Email e senha são obrigatórios" });
  }

  // 2) Validação de email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(emailEmpresa)) {
    return res.status(400).json({ message: "Formato de email inválido" });
  }

  // 3) Validação de senha
  if (senhaEmpresa.length < 6) {
    return res.status(400).json({ message: "A senha deve ter pelo menos 6 caracteres" });
  }

  try {
    // 4) Consulta no banco
    const rows = await sequelize.query(
      'SELECT * FROM tbEmpresa WHERE emailEmpresa = :email AND senhaEmpresa = :senha',
      {
        replacements: { email: emailEmpresa, senha: senhaEmpresa },
        type: QueryTypes.SELECT
      }
    );

    if (rows.length === 0) {
      return res.status(401).json({ message: "Usuário inexistente " });
    }

    const empresa = rows[0];

   
    return res.json({
      message: "Login bem-sucedido",
      empresa: {
        id: empresa.IDEmpresa,
        nome: empresa.nomeEmpresa,
        email: empresa.emailEmpresa
      }
    });
  } catch (error) {
    console.error("Erro no login:", error);
    return res.status(500).json({ message: "Erro interno no servidor" });
  }
};
