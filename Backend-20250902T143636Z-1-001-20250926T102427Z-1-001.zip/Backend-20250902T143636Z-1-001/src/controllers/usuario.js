const express = require("express");
const router = express.Router();
const db = require("../db");

// CREATE
router.post("/", (req, res) => {
  const { nomeUsuario, emailUsuario, senhaUsuario, isAdmin, IDEmpresa } = req.body;
  db.query(
    "INSERT INTO tbUsuario (nomeUsuario, emailUsuario, senhaUsuario, isAdmin, IDEmpresa) VALUES (?, ?, ?, ?, ?)",
    [nomeUsuario, emailUsuario, senhaUsuario, isAdmin, IDEmpresa],
    (err, result) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ message: "Usuário cadastrado!", id: result.insertId });
    }
  );
});

// READ ALL
router.get("/", (req, res) => {
  db.query("SELECT * FROM tbUsuario", (err, results) => {
    if (err) return res.status(500).json({ error: err });
    res.json(results);
  });
});

// READ ONE
router.get("/:id", (req, res) => {
  const { id } = req.params;
  db.query("SELECT * FROM tbUsuario WHERE IDUsuario=?", [id], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json(result[0]);
  });
});

// UPDATE
router.put("/:id", (req, res) => {
  const { id } = req.params;
  const { nomeUsuario, emailUsuario, senhaUsuario, isAdmin, IDEmpresa } = req.body;
  db.query(
    "UPDATE tbUsuario SET nomeUsuario=?, emailUsuario=?, senhaUsuario=?, isAdmin=?, IDEmpresa=? WHERE IDUsuario=?",
    [nomeUsuario, emailUsuario, senhaUsuario, isAdmin, IDEmpresa, id],
    (err) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ message: "Usuário atualizado!" });
    }
  );
});

// DELETE
router.delete("/:id", (req, res) => {
  const { id } = req.params;
  db.query("DELETE FROM tbUsuario WHERE IDUsuario=?", [id], (err) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: "Usuário deletado!" });
  });
});

module.exports = router;
