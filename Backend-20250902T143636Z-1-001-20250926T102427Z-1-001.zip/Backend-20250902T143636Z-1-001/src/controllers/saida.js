const express = require("express");
const router = express.Router();
const db = require("../db");

// CREATE
router.post("/", (req, res) => {
  const { dataSaida, quantProduto, IDProduto } = req.body;
  db.query(
    "INSERT INTO tbSaidaEstoque (dataSaida, quantProduto, IDProduto) VALUES (?, ?, ?)",
    [dataSaida, quantProduto, IDProduto],
    (err, result) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ message: "Saída registrada!", id: result.insertId });
    }
  );
});

// READ ALL
router.get("/", (req, res) => {
  db.query("SELECT * FROM tbSaidaEstoque", (err, results) => {
    if (err) return res.status(500).json({ error: err });
    res.json(results);
  });
});

// READ ONE
router.get("/:id", (req, res) => {
  const { id } = req.params;
  db.query("SELECT * FROM tbSaidaEstoque WHERE IDSaidaEstoque=?", [id], (err, result) => {
    if (err) return res.status(500).json({ error: err });
    res.json(result[0]);
  });
});

// UPDATE
router.put("/:id", (req, res) => {
  const { id } = req.params;
  const { dataSaida, quantProduto, IDProduto } = req.body;
  db.query(
    "UPDATE tbSaidaEstoque SET dataSaida=?, quantProduto=?, IDProduto=? WHERE IDSaidaEstoque=?",
    [dataSaida, quantProduto, IDProduto, id],
    (err) => {
      if (err) return res.status(500).json({ error: err });
      res.json({ message: "Saída atualizada!" });
    }
  );
});

// DELETE
router.delete("/:id", (req, res) => {
  const { id } = req.params;
  db.query("DELETE FROM tbSaidaEstoque WHERE IDSaidaEstoque=?", [id], (err) => {
    if (err) return res.status(500).json({ error: err });
    res.json({ message: "Saída deletada!" });
  });
});

module.exports = router;
