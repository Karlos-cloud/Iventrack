import { Sequelize } from 'sequelize';

export const sequelize = new Sequelize('dbIventrack', 'root', 'root', {
  host: 'localhost',
  dialect: 'mysql'
});

try {
  await sequelize.authenticate();
  console.log('Conectado ao MySQL via Sequelize!');
} catch (error) {
  console.error('Erro ao conectar:', error);
}